package dev.Paveewuth.handytools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadDatabase {

    public static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

    @Bean
    CommandLineRunner initDatabase(StorageRepository repository) {
        return args -> {
            log.info("loading " + repository.save(new Storage("The Great Gatsby", "Library Shelf A", false, null)));
            log.info("loading " + repository.save(new Storage("1984", "Library Shelf B", false, null)));
            log.info("loading " + repository.save(new Storage("To Kill a Mockingbird", "Library Shelf C", false, null)));
        };
    }
}
