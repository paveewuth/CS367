package dev.Paveewuth.handytools;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
public class BookRentalController {
    private final StorageRepository repository;

    BookRentalController(StorageRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/bookrental")    
    List<Storage> findAll() {
        return repository.findAll();
    }

    @GetMapping("/bookrental/{id}")
    Storage findOne(@PathVariable Long id) {
        Optional<Storage> book = repository.findById(id);
        if (book.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No book found with the given id");
        }
        return book.get();
    }
    
    @PostMapping("/bookrental")
    Storage newBook(@RequestBody Storage book) {        
        return repository.save(book);
    }
    
    @PutMapping("/bookrental/{id}")
    Storage saveBook(@RequestBody Storage newBook, @PathVariable Long id) {
        return repository.findById(id).map(book -> {
            book.setBorrowed(newBook.getBorrowed());
            book.setBorrowerName(newBook.getBorrowerName());
            book.setLocationName(newBook.getLocationName());
            book.setBookDetail(newBook.getBookDetail());
            return repository.save(book);
        }).orElseGet(() -> {
            return repository.save(newBook);
        });
    }
    
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("/bookrental/{id}")
    void deleteBook(@PathVariable Long id) {
        repository.deleteById(id);
    }
}
