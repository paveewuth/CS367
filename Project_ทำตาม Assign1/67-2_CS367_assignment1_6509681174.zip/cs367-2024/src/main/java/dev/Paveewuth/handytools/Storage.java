package dev.Paveewuth.handytools;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Storage {
    private @Id
    @GeneratedValue Long id;
    private String bookDetail;
    private String locationName;
    private Boolean borrowed;
    private String borrowerName;

    Storage() {}

    public Storage(String bookDetail, String locationName, Boolean borrowed, String borrowerName) {
        this.bookDetail = bookDetail;
        this.locationName = locationName;
        this.borrowed = borrowed;
        this.borrowerName = borrowerName;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getBookDetail() {
        return bookDetail;
    }
    public void setBookDetail(String bookDetail) {
        this.bookDetail = bookDetail;
    }
    public String getLocationName() {
        return locationName;
    }
    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }
    public Boolean getBorrowed() {
        return borrowed;
    }
    public void setBorrowed(Boolean borrowed) {
        this.borrowed = borrowed;
    }
    public String getBorrowerName() {
        return borrowerName;
    }
    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((bookDetail == null) ? 0 : bookDetail.hashCode());
        result = prime * result + ((locationName == null) ? 0 : locationName.hashCode());
        result = prime * result + ((borrowed == null) ? 0 : borrowed.hashCode());
        result = prime * result + ((borrowerName == null) ? 0 : borrowerName.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Storage other = (Storage) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (bookDetail == null) {
            if (other.bookDetail != null)
                return false;
        } else if (!bookDetail.equals(other.bookDetail))
            return false;
        if (locationName == null) {
            if (other.locationName != null)
                return false;
        } else if (!locationName.equals(other.locationName))
            return false;
        if (borrowed == null) {
            if (other.borrowed != null)
                return false;
        } else if (!borrowed.equals(other.borrowed))
            return false;
        if (borrowerName == null) {
            if (other.borrowerName != null)
                return false;
        } else if (!borrowerName.equals(other.borrowerName))
            return false;
        return true;
    }
    
    @Override
    public String toString() {
        return "Storage [id=" + id + ", bookDetail=" + bookDetail + ", locationName="
                + locationName + ", borrowed=" + borrowed + ", borrowerName=" + borrowerName + "]";
    }
}
